import { prisma } from "../config/prisma.js";
import { hashPassword, verifyPassword } from "./passwordService.js";

export async function registerUser({ name, email, password }) {
    const existing = await prisma.user.findUnique({
        where: { email }
    });

    if (existing) {
        throw new Error("Email already registered");
    }

    const passwordHash = await hashPassword(password);

    return prisma.user.create({
        data: {
            name,
            email,
            passwordHash
        },
        select: {
            id: true,
            name: true,
            email: true,
            role: true
        }
    });
}

export async function authenticateUser(email, password) {
    const user = await prisma.user.findUnique({
        where: { email }
    });

    if (!user) {
        return null;
    }

    const valid = await verifyPassword(
        user.passwordHash,
        password
    );

    if (!valid) {
        return null;
    }

    return {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
    };
}
