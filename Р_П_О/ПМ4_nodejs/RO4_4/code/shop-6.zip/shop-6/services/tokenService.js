import jwt from "jsonwebtoken";

export function createAccessToken(user) {
    return jwt.sign(
        {
            role: user.role
        },
        process.env.JWT_SECRET,
        {
            algorithm: "HS256",
            subject: String(user.id),
            issuer: process.env.JWT_ISSUER,
            audience: process.env.JWT_AUDIENCE,
            expiresIn: process.env.JWT_EXPIRES_IN
        }
    );
}

export function verifyAccessToken(token) {
    return jwt.verify(
        token,
        process.env.JWT_SECRET,
        {
            algorithms: ["HS256"],
            issuer: process.env.JWT_ISSUER,
            audience: process.env.JWT_AUDIENCE
        }
    );
}