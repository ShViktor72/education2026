let accessToken = null;
let currentUser = null;

export function setAuth(data) {
    accessToken = data.accessToken;
    currentUser = data.user;
}

export function clearAuth() {
    accessToken = null;
    currentUser = null;
}

export function getAccessToken() {
    return accessToken;
}

export function getCurrentUser() {
    return currentUser;
} 