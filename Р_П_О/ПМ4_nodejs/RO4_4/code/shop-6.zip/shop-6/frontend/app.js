import { apiFetch, APIError } from "./api.js";
import { setAuth, clearAuth, getCurrentUser } from "./authState.js";

const guestSection = document.querySelector("#guest-section");
const catalogSection = document.querySelector("#catalog-section");
const profileSection = document.querySelector("#profile-section");
const adminSection = document.querySelector("#admin-section");

const loginLink = document.querySelector("#login-link");
const profileLink = document.querySelector("#profile-link");
const adminLink = document.querySelector("#admin-link");

const form = document.querySelector("#login-form");
const emailInput = document.querySelector("#email");
const passwordInput = document.querySelector("#password");
const loginButton = document.querySelector("#login-button");
const loginError = document.querySelector("#login-error");

const profileName = document.querySelector("#profile-name");
const logoutButton = document.querySelector("#logout-button");
const ordersButton = document.querySelector("#orders-button");
const ordersStatus = document.querySelector("#orders-status");
const ordersList = document.querySelector("#orders-list");

const catalogStatus = document.querySelector("#catalog-status");
const productsList = document.querySelector("#products-list");

function showOnly(section) {
    for (const item of [guestSection, catalogSection, profileSection, adminSection]) {
        item.hidden = item !== section;
    }
}

function renderNavigation() {
    const user = getCurrentUser();
    loginLink.hidden = Boolean(user);
    profileLink.hidden = !user;
    adminLink.hidden = user?.role !== "admin";
}

function requireUser() {
    if (!getCurrentUser()) {
        location.hash = "#/login";
        return false;
    }
    return true;
}

function requireAdmin() {
    const user = getCurrentUser();
    if (!user) {
        location.hash = "#/login";
        return false;
    }
    if (user.role !== "admin") {
        alert("Недостаточно прав");
        location.hash = "#/catalog";
        return false;
    }
    return true;
}

async function loadProducts() {
    catalogStatus.textContent = "Загрузка товаров...";
    productsList.replaceChildren();
    try {
        // Предполагается, что backend реализует GET /api/products.
        const data = await apiFetch("/products");
        const products = Array.isArray(data) ? data : data?.products;
        if (!Array.isArray(products)) {
            throw new Error("Неожиданный формат ответа /api/products");
        }
        catalogStatus.textContent = products.length
            ? `Товаров: ${products.length}`
            : "Товары отсутствуют";
        for (const product of products) {
            const item = document.createElement("div");
            item.textContent = `${product.name} — ${product.price} ₸`;
            productsList.append(item);
        }
    } catch (error) {
        catalogStatus.textContent = `Не удалось загрузить товары: ${error.message}`;
    }
}

function renderPage() {
    const page = location.hash || "#/catalog";
    if (page === "#/profile") {
        if (!requireUser()) return;
        profileName.textContent = `Здравствуйте, ${getCurrentUser().name ?? getCurrentUser().email}`;
        showOnly(profileSection);
    } else if (page === "#/admin") {
        if (!requireAdmin()) return;
        showOnly(adminSection);
    } else if (page === "#/login") {
        if (getCurrentUser()) {
            location.hash = "#/profile";
            return;
        }
        showOnly(guestSection);
    } else {
        showOnly(catalogSection);
        void loadProducts();
    }
}

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    loginError.textContent = "";
    loginButton.disabled = true;
    try {
        const data = await apiFetch("/auth/login", {
            method: "POST",
            body: { email: emailInput.value, password: passwordInput.value }
        });
        if (!data?.accessToken || !data?.user) {
            throw new Error("Сервер не вернул accessToken или user");
        }
        setAuth(data);
        form.reset();
        renderNavigation();
        location.hash = "#/profile";
        renderPage(); // Срабатывает и если hash уже был #/profile.
    } catch (error) {
        loginError.textContent = error.message;
    } finally {
        loginButton.disabled = false;
    }
});

ordersButton.addEventListener("click", async () => {
    ordersStatus.textContent = "Загрузка...";
    ordersList.replaceChildren();
    try {
        // Работает только при наличии GET /api/orders/my на backend.
        const orders = await apiFetch("/orders/my");
        if (!Array.isArray(orders)) {
            throw new Error("Неожиданный формат ответа /api/orders/my");
        }
        ordersStatus.textContent = `Заказов: ${orders.length}`;
        for (const order of orders) {
            const item = document.createElement("div");
            item.textContent = `Заказ #${order.id}: ${order.status}`;
            ordersList.append(item);
        }
    } catch (error) {
        ordersStatus.textContent = error.message;
        if (error instanceof APIError && error.status === 401) {
            renderNavigation();
            location.hash = "#/login";
            renderPage();
        }
    }
});

logoutButton.addEventListener("click", () => {
    clearAuth();
    ordersList.replaceChildren();
    ordersStatus.textContent = "";
    renderNavigation();
    location.hash = "#/login";
    renderPage();
});

window.addEventListener("hashchange", renderPage);
renderNavigation();
renderPage();
