export class APIError extends Error {
    constructor(message, status) {
        super(message);
        this.status = status;
    }
}

import { API_URL } from "./config.js";
import {
    getAccessToken,
    clearAuth
} from "./authState.js";

export async function apiFetch(
    path,
    { body, headers = {}, ...options } = {}
) {
    const token = getAccessToken();

    const response = await fetch(`${API_URL}${path}`, {
        ...options,
        headers: {
            ...(body ? { "Content-Type": "application/json" } : {}),
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
            ...headers
        },
        body: body ? JSON.stringify(body) : undefined
    });

    let data = null;

    if (response.status !== 204) {
        data = await response.json();
    }

    if (response.status === 401) {
        clearAuth();
    }

    if (!response.ok) {
        throw new APIError(
            data?.error ?? `HTTP ${response.status}`,
            response.status
        );
    }

    return data;
}