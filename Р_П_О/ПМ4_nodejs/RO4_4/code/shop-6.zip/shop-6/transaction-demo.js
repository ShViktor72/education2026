import { prisma } from "./config/prisma.js";

async function main() {
    try {
        await prisma.$transaction(async (tx) => {
            // Операция 1 — категория существует.
            await tx.products.create({
                data: {
                    name: "LAB9 Кабель",
                    price: 2500,
                    description: "Учебный товар",
                    in_stock: true,
                    category_id: 2
                }
            });

            // Операция 2 — категория отсутствует, будет ошибка.
            await tx.products.create({
                data: {
                    name: "LAB9 Чехол",
                    price: 3900,
                    description: "Учебный товар",
                    in_stock: true,
                    category_id: 1
                }
            });
        });
        console.log("COMMIT: оба товара добавлены");
    } catch (error) {
        console.log("ROLLBACK:", error.code ?? error.message);
    } finally {
        await prisma.$disconnect();
    }
}

main();

