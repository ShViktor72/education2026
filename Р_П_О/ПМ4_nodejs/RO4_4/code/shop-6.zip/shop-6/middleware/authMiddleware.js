import { verifyAccessToken } from "../services/tokenService.js";

function getBearerToken(req) {
    const header = req.headers.authorization;

    if (!header) {
        return null;
    }

    const [scheme, token] = header.split(" ");

    if (scheme !== "Bearer" || !token) {
        return null;
    }

    return token;
}

export function requireAuth(req, res, next) {
    const token = getBearerToken(req);

    if (!token) {
        return res.status(401).json({
            error: "Authentication required"
        });
    }

    try {
        const payload = verifyAccessToken(token);

        req.user = {
            id: Number(payload.sub),
            role: payload.role
        };

        next();
    } catch {
        return res.status(401).json({
            error: "Invalid or expired token"
        });
    }
}

export function requireRole(...allowedRoles) {
    return function (req, res, next) {
        if (!req.user) {
            return res.status(401).json({
                error: "Authentication required"
            });
        }

        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({
                error: "Forbidden"
            });
        }

        next();
    };
}
