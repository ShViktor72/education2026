import * as argon2 from "argon2";

const password = "1";

const hash1 = await argon2.hash(password);
const hash2 = await argon2.hash(password);

console.log("Первый хеш:", hash1);
console.log("Второй хеш:", hash2);
console.log("Хеши равны:", hash1 === hash2);

console.log("Верный пароль:",
    await argon2.verify(hash1, password));
console.log("Неверный пароль:",
    await argon2.verify(hash1, "WrongPassword!"));
