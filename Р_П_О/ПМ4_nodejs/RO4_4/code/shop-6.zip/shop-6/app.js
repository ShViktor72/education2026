import express from "express";

import productRoutes from "./routes/productRoutes.js";
import categoryRoutes from "./routes/categoryRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import userRouts from "./routes/userRoutes.js"

import { errorHandler } from "./middleware/errorHandler.js";

const app = express();

app.use(express.json());
app.use(express.static("frontend"));

app.use("/api/products", productRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/users", userRouts)

// Обработка неизвестных маршрутов
app.use((req, res) => {
    res.status(404).json({
        message: "Route not found"
    });
});

// Обработчик ошибок — обязательно последним
app.use(errorHandler);

app.listen(3000, () => {
    console.log("Server started on port 3000");
});