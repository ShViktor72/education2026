import { prisma } from "../config/prisma.js";

const safeUser = { id: true, name: true, email: true, role: true };

export async function getMe(req, res, next) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      select: safeUser
    });
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user);
  } catch (error) {
    next(error);
  }
}

export async function getUsers(req, res, next) {
  try {
    const users = await prisma.user.findMany({ select: safeUser });
    res.json(users);
  } catch (error) {
    next(error);
  }
}
