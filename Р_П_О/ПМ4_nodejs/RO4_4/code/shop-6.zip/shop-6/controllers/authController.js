import { registerUser, authenticateUser } from "../services/authService.js";
import { createAccessToken } from "../services/tokenService.js";
import { prisma } from "../config/prisma.js";

export async function register(req, res, next) {
    try {
        const user = await registerUser(req.body);
        res.status(201).json({ user });
    } catch (error) {
        next(error);
    }
}

// laba 2
// export async function login(req, res, next) {
//     try {
//         const { email, password } = req.body;
//         const user = await authenticateUser(email, password);

//         if (!user) {
//             return res.status(401).json({
//                 error: "Invalid email or password"
//             });
//         }

//         res.json({ user });
//     } catch (error) {
//         next(error);
//     }
// }

// laba 3
export async function login(req, res, next) {
    try {
        const { email, password } = req.body;
        const user = await authenticateUser(email, password);

        if (!user) {
            return res.status(401).json({
                error: "Invalid email or password"
            });
        }

        const accessToken = createAccessToken(user);

        res.json({
            user,
            accessToken
        });
    } catch (error) {
        next(error);
    }
}


export async function getCurrentUser(req, res, next) {
    try {
        const user = await prisma.user.findUnique({
            where: {
                id: req.user.id
            },
            select: {
                id: true,
                name: true,
                email: true,
                role: true
            }
        });

        if (!user) {
            return res.status(401).json({
                error: "User not found"
            });
        }

        res.json({ user });
    } catch (error) {
        next(error);
    }
} 