import { Router } from "express";
import * as controller from "../controllers/categoryController.js";
import { validateId } from "../middleware/validateProduct.js";
import { requireAuth, requireRole } from "../middleware/authMiddleware.js";


const router = Router();

router.get("/", controller.getCategories);

// новые маршруты
router.get(
    "/with-products",
    controller.getWithProducts
);

router.get("/some", controller.getSome);
router.get("/every", controller.getEvery);
router.get("/none", controller.getNone);

//
router.get("/:id", validateId, controller.getCategoryById);

// Создание, изменение и удаление категорий разрешены только admin
router.post("/", requireAuth, requireRole("admin"), controller.createCategory);

export default router;
