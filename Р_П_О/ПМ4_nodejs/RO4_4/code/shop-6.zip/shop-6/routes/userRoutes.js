import { Router } from "express";
import * as controller from "../controllers/userController.js";
import { requireAuth, requireRole } from "../middleware/authMiddleware.js";

const router = Router();
router.get("/me", requireAuth, controller.getMe);
router.get("/", requireAuth, requireRole("admin"), controller.getUsers);

export default router;
