// Устанавливаем Express и PostgreSQL-драйвер
// npm install express pg

import express from "express";

import productRoutes from "./routes/productRoutes.js";

const app = express();


// Позволяет Express читать JSON.
// Для двух GET-маршрутов пока не обязательно,
// но оставляем для дальнейшего CRUD.
app.use(express.json());


// Все маршруты товаров.
app.use("/api/products", productRoutes);


// Простой обработчик ошибок.
app.use((error, req, res, next) => {
    console.error(error);

    res.status(500).json({
        error: "Internal server error"
    });
});


app.listen(3000, () => {
    console.log("Server: http://localhost:3000");
});