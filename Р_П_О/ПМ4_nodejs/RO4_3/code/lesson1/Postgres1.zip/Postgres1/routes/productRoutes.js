import { Router } from "express";

import {
    getProducts,
    getProductById
} from "../controllers/productController.js";

const router = Router();

// Получить все товары.
router.get("/", getProducts);

// Получить товар по id.
router.get("/:id", getProductById);

export default router;