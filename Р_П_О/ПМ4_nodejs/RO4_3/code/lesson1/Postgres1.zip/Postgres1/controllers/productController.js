import {
    getAllProducts,
    findProductById
} from "../services/productService.js";


// GET /api/products
export async function getProducts(req, res, next) {
    try {
        // Service обращается к PostgreSQL.
        const products = await getAllProducts();

        // Отправляем массив клиенту.
        res.json(products);

    } catch (error) {
        // Передаём ошибку следующему middleware.
        next(error);
    }
}


// GET /api/products/:id
export async function getProductById(req, res, next) {
    try {
        // req.params.id приходит как строка.
        const id = Number(req.params.id);

        // Ждём результат SQL-запроса.
        const product = await findProductById(id);

        // Товар не найден.
        if (!product) {
            return res.status(404).json({
                error: "Product not found"
            });
        }

        res.json(product);

    } catch (error) {
        next(error);
    }
}