import { pool } from "../config/db.js";

// Получить все товары.
export async function getAllProducts() {

    // Отправляем SQL-запрос в PostgreSQL.
    const result = await pool.query(`
        SELECT
            id,
            name,
            price,
            category,
            in_stock AS "inStock"
        FROM products
        ORDER BY id
    `);

    // result.rows — обычный массив JavaScript-объектов.
    return result.rows;
}


// Получить один товар по id.
export async function findProductById(id) {

    // $1 — параметр SQL-запроса.
    // Значение id передаётся отдельно.
    const result = await pool.query(
        `
        SELECT
            id,
            name,
            price,
            category,
            in_stock AS "inStock"
        FROM products
        WHERE id = $1
        `,
        [id]
    );

    // Первый найденный товар.
    // Если ничего не найдено — undefined.
    return result.rows[0];
}