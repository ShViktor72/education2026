import * as service from "../services/productService.js";

// GET /api/products
export async function getProducts(req, res) {
    const products = await service.getAllProducts();

    res.json(products);
}

// GET /api/products/:id
export async function getProductById(req, res) {
    const product = await service.findProductById(
        Number(req.params.id)
    );

    if (!product) {
        return res.status(404).json({
            message: "Product not found"
        });
    }

    res.json(product);
}

// POST /api/products
export async function createProduct(req, res) {
    const product = await service.addProduct(req.body);

    res.status(201).json(product);
}

// PATCH /api/products/:id
export async function updateProduct(req, res) {
    const product = await service.updateProductById(
        Number(req.params.id),
        req.body
    );

    res.json(product);
}

// DELETE /api/products/:id
export async function deleteProduct(req, res) {
    const product = await service.deleteProductById(
        Number(req.params.id)
    );

    res.json(product);
}