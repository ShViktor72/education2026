import * as service from "../services/categoryService.js";

export async function getCategories(req, res) {
    const categories = await service.getAllCategories();

    res.json(categories);
}

export async function getCategoryById(req, res) {
    const category = await service.findCategoryById(
        Number(req.params.id)
    );

    if (!category) {
        return res.status(404).json({
            message: "Category not found"
        });
    }

    res.json(category);
}