import { Router } from "express";

import * as controller from "../controllers/categoryController.js";

import { validateId } from "../middleware/validateProduct.js";

const router = Router();

router.get("/", controller.getCategories);

router.get("/:id", validateId, controller.getCategoryById);

export default router;
