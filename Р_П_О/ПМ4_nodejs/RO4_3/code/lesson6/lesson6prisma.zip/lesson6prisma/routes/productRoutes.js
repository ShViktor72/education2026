import { Router } from "express";

import * as controller from "../controllers/productController.js";

import {
    validateId,
    validateProduct
} from "../middleware/validateProduct.js";

const router = Router();

router.get("/", controller.getProducts);

router.get(
    "/:id",
    validateId,
    controller.getProductById
);

router.post(
    "/",
    validateProduct,
    controller.createProduct
);

router.patch(
    "/:id",
    validateId,
    validateProduct,
    controller.updateProduct
);

router.delete(
    "/:id",
    validateId,
    controller.deleteProduct
);

export default router;