import { prisma } from "../config/prisma.js";

export async function getAllCategories() {
    return prisma.categories.findMany({
        orderBy: { id: "asc" }
    });
}

export async function findCategoryById(id) {
    return prisma.categories.findUnique({
        where: { id }
    });
}