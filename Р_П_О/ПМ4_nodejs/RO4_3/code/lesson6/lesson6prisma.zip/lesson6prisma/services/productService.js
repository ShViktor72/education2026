import { prisma } from "../config/prisma.js";

// READ — список товаров
export async function getAllProducts() {
    return prisma.products.findMany({
        orderBy: { id: "asc" },
        include: { categories: true }
    });
}

// READ — товар по ID
export async function findProductById(id) {
    return prisma.products.findUnique({
        where: { id },
        include: { categories: true }
    });
}

// CREATE — добавить товар
export async function addProduct(data) {
    return prisma.products.create({
        data: {
            name: data.name,
            price: data.price,
            category_id: data.category_id,
            in_stock: data.in_stock ?? true
        },
        include: { categories: true }
    });
}

// UPDATE — частичное изменение
export async function updateProductById(id, changes) {
    return prisma.products.update({
        where: { id },
        data: changes,
        include: { categories: true }
    });
}

// DELETE — удалить товар
export async function deleteProductById(id) {
    return prisma.products.delete({
        where: { id },
        include: { categories: true }
    });
}