import { getAllProducts } from "../services/productService.js";

// GET /api/products
export async function getProducts(req, res) {
    const products = await getAllProducts();

    res.json(products);
}