import express from "express";
import productRoutes from "./routes/productRoutes.js";

const app = express();

app.use(express.json());

// Маршрут товаров
app.use("/api/products", productRoutes);

app.listen(3000, () => {
    console.log("Server started on port 3000");
});