import { prisma } from "../config/prisma.js";

// Получение всех товаров
export async function getAllProducts() {
    return prisma.products.findMany({
        orderBy: { id: "asc" },
        include: { categories: true }
    });
}