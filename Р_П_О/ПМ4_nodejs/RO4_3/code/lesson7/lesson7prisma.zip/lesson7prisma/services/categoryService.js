import { prisma } from "../config/prisma.js";

export async function getAllCategories() {
    return prisma.categories.findMany({
        orderBy: { id: "asc" }
    });
}

export async function findCategoryById(id) {
    return prisma.categories.findUnique({
        where: { id }
    });
}

// новые функции
// 1. Категории со всеми товарами
export async function getCategoriesWithProducts() {
    return prisma.categories.findMany({
        include: {
            products: true
        }
    });
}

// 2. Категории, где есть хотя бы один товар в наличии
export async function getCategoriesSome() {
    return prisma.categories.findMany({
        where: {
            products: {
                some: { in_stock: true }
            }
        },
        include: { products: true }
    });
}

// 3. Категории, где все товары имеются в наличии
export async function getCategoriesEvery() {
    return prisma.categories.findMany({
        where: {
            products: {
                some: {},
                every: { in_stock: true }
            }
        },
        include: { products: true }
    });
}

// 4. Категории, где нет товаров в наличии
export async function getCategoriesNone() {
    return prisma.categories.findMany({
        where: {
            products: {
                none: { in_stock: true }
            }
        },
        include: { products: true }
    });
}