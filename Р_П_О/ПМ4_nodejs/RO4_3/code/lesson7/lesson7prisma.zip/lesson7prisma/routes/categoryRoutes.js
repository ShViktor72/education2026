import { Router } from "express";

import * as controller from "../controllers/categoryController.js";

import { validateId } from "../middleware/validateProduct.js";

const router = Router();

router.get("/", controller.getCategories);

// новые маршруты
router.get(
    "/with-products",
    controller.getWithProducts
);

router.get("/some", controller.getSome);
router.get("/every", controller.getEvery);
router.get("/none", controller.getNone);

//
router.get("/:id", validateId, controller.getCategoryById);

export default router;
