import { Router } from "express";

import * as controller from "../controllers/productController.js";

import {
    validateId,
    validateProduct
} from "../middleware/validateProduct.js";

const router = Router();

router.get("/", controller.getProducts);

// новые маршруты
router.get(
    "/with-categories",
    controller.getWithCategories
);

router.get(
    "/selected",
    controller.getSelectedProducts
);

router.get(
    "/by-category",
    controller.getByCategory
);

router.get(
    "/by-category-id/:id",
    validateId,
    controller.getByCategoryId
);


// старые маршруты
router.get(
    "/:id",
    validateId,
    controller.getProductById
);

router.post(
    "/",
    validateProduct,
    controller.createProduct
);

router.patch(
    "/:id",
    validateId,
    validateProduct,
    controller.updateProduct
);

router.delete(
    "/:id",
    validateId,
    controller.deleteProduct
);

export default router;