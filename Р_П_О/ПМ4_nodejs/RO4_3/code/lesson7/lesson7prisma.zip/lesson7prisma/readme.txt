npm install -D prisma@7 typescript tsx @types/node @types/pg
npm install @prisma/client@7 @prisma/adapter-pg pg dotenv
npx prisma init --datasource-provider postgresql --output ../generated/prisma
npx prisma db pull
npx prisma validate
npx prisma generate


DATABASE_URL="postgresql://shop_user:college123@localhost:5432/shop_db?schema=public"

1. Какие файлы создаются автоматически
Файл или папка	        Как появляется	           Нужно ли создавать вручную?
package.json	        npm init -y	               Нет
node_modules/	        npm install	               Нет
prisma.config.ts	    npx prisma init	           Нет, только настроить
.env	                npx prisma init	           Обычно создаётся; заполнить
prisma/schema.prisma	npx prisma init	           Нет, затем изменить
Модели 	                npx prisma db pull	       Генерируются из БД, затем корректируются
generated/prisma/	    npx prisma generate	       Нет