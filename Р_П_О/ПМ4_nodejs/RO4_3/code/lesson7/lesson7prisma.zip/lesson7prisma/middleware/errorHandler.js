export function errorHandler(err, req, res, next) {

    // Товар или другая запись не найдены
    if (err.code === "P2025") {
        return res.status(404).json({
            message: "Record not found"
        });
    }

    // Нарушение внешнего ключа
    if (err.code === "P2003") {
        return res.status(409).json({
            message: "Foreign key constraint violation"
        });
    }

    // Ошибка формата JSON
    if (err instanceof SyntaxError &&
        err.status === 400 &&
        "body" in err) {
        return res.status(400).json({
            message: "Invalid JSON"
        });
    }

    console.error(err);

    res.status(500).json({
        message: "Internal Server Error"
    });
}