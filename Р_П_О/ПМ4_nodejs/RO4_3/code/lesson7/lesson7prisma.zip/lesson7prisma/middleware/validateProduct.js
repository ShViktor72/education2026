// Проверка ID в URL
export function validateId(req, res, next) {
    const id = Number(req.params.id);

    if (!Number.isSafeInteger(id) || id <= 0) {
        return res.status(400).json({
            message: "Invalid product ID"
        });
    }

    next();
}

// Проверка тела POST и PATCH
export function validateProduct(req, res, next) {
    const data = req.body;

    if (!data || typeof data !== "object" ||
        Array.isArray(data)) {
        return res.status(400).json({
            message: "Expected JSON object"
        });
    }

    const isPost = req.method === "POST";

    const allowed = [
        "name", "price", "category_id", "in_stock"
    ];

    const keys = Object.keys(data);

    if (keys.some(key => !allowed.includes(key))) {
        return res.status(400).json({
            message: "Unknown product field"
        });
    }

    if (!isPost && keys.length === 0) {
        return res.status(400).json({
            message: "No fields to update"
        });
    }

    // Для POST обязательны основные поля
    if (isPost && (
        data.name === undefined ||
        data.price === undefined ||
        data.category_id === undefined
    )) {
        return res.status(400).json({
            message: "Required: name, price, category_id"
        });
    }

    if (data.name !== undefined &&
        (typeof data.name !== "string" ||
         data.name.trim().length === 0 ||
         data.name.length > 150)) {
        return res.status(400).json({
            message: "Invalid name"
        });
    }

    if (data.price !== undefined &&
        (!Number.isSafeInteger(data.price) || data.price < 0)) {
        return res.status(400).json({
            message: "Invalid price"
        });
    }

    if (data.category_id !== undefined &&
        (!Number.isSafeInteger(data.category_id) ||
         data.category_id <= 0)) {
        return res.status(400).json({
            message: "Invalid category_id"
        });
    }

    if (data.in_stock !== undefined &&
        typeof data.in_stock !== "boolean") {
        return res.status(400).json({
            message: "Invalid in_stock"
        });
    }

    next();
}