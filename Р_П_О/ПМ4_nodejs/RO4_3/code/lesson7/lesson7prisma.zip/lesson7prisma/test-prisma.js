import { prisma } from "./config/prisma.js";

try {
    // Получаем все категории
    const categories = await prisma.categories.findMany({
        orderBy: { id: "asc" }
    });

    console.log("КАТЕГОРИИ:");
    console.table(categories);

    // Получаем все товары
    const products = await prisma.products.findMany({
        orderBy: { id: "asc" }
    });

    console.log("ТОВАРЫ:");
    console.table(products);

    // Получаем товары вместе с категориями
    const productsWithCategories = await prisma.products.findMany({
        include: { categories: true }
    });

    console.log("ТОВАРЫ С КАТЕГОРИЯМИ:");
    console.dir(productsWithCategories, { depth: null });

} catch (error) {
    console.error("Ошибка:", error);
} finally {
    await prisma.$disconnect();
}