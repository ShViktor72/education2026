import * as service from "../services/categoryService.js";

export async function getCategories(req, res) {
    const categories = await service.getAllCategories();

    res.json(categories);
}

export async function getCategoryById(req, res) {
    const category = await service.findCategoryById(
        Number(req.params.id)
    );

    if (!category) {
        return res.status(404).json({
            message: "Category not found"
        });
    }

    res.json(category);
}

// Новые обработчики
// GET /api/categories/with-products
export async function getWithProducts(req, res) {
    res.json(
        await service.getCategoriesWithProducts()
    );
}

// GET /api/categories/some
export async function getSome(req, res) {
    res.json(
        await service.getCategoriesSome()
    );
}

// GET /api/categories/every
export async function getEvery(req, res) {
    res.json(
        await service.getCategoriesEvery()
    );
}

// GET /api/categories/none
export async function getNone(req, res) {
    res.json(
        await service.getCategoriesNone()
    );
}