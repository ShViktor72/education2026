npm install -D prisma@7 typescript tsx @types/node @types/pg
npm install @prisma/client@7 @prisma/adapter-pg pg dotenv
npx prisma init --datasource-provider postgresql --output ../generated/prisma
npx prisma db pull
npx prisma validate
npx prisma generate


DATABASE_URL="postgresql://shop_user:college123@localhost:5432/shop_db?schema=public"

1. Какие файлы создаются автоматически
Файл или папка	        Как появляется	           Нужно ли создавать вручную?
package.json	        npm init -y	               Нет
node_modules/	        npm install	               Нет
prisma.config.ts	    npx prisma init	           Нет, только настроить
.env	                npx prisma init	           Обычно создаётся; заполнить
prisma/schema.prisma	npx prisma init	           Нет, затем изменить
Модели 	                npx prisma db pull	       Генерируются из БД, затем корректируются
generated/prisma/	    npx prisma generate	       Нет

##########################################################################
Лекция 8. Миграции.
1. Проверить состояние миграций:
npx prisma@7 migrate status

2. В prisma/schema.prisma модель Product добавить:
description String?

3. Создаём начальную миграцию 0_init из реальной базы
New-Item -ItemType Directory -Force prisma\migrations\0_init

Теперь создаём SQL, описывающий то, что реально сейчас находится в shop_db1:
npx prisma@7 migrate diff --from-empty --to-config-datasource --script --output prisma/migrations/0_init/migration.sql

Отмечаем 0_init как уже выполненную. Выполняем:
npx prisma@7 migrate resolve --applied 0_init

Проверяем:
npx prisma@7 migrate status

4. Создать миграцию (У владельца БД переключатель Can create databases? =>  Yes):
npx prisma@7 migrate dev --name add-product-description

5. Генерируем Prisma Client
npx prisma@7 generate

##########################################################################
начальное заполнение данных
##########################################################################
1. В файл конфигурации Prisma prisma7.config.ts  в секцию migrations добавить:
seed: "node prisma/seed.js"

2. Создайте файл prisma/seed.js
import { prisma } from "../config/prisma.js";

async function getOrCreateCategory(name) {
  // Сначала ищем категорию по имени
  const existingCategory = await prisma.categories.findFirst({
    where: {
      name: name
    }
  });

  if (existingCategory) {
    return existingCategory;
  }

  // Так как id не autoincrement,
  // определяем следующий свободный id
  const result = await prisma.categories.aggregate({
    _max: {
      id: true
    }
  });

  const nextId = (result._max.id ?? 0) + 1;

  return prisma.categories.create({
    data: {
      id: nextId,
      name: name
    }
  });
}


async function main() {

  // ==========================
  // Категории
  // ==========================

  const laptops = await getOrCreateCategory("Ноутбуки");

  const accessories = await getOrCreateCategory("Аксессуары");

  console.log("Категории:");
  console.log({ laptops, accessories });


  // ==========================
  // Laptop Pro
  // ==========================

  const existingLaptop = await prisma.products.findFirst({
    where: {
      name: "Laptop Pro"
    }
  });

  if (!existingLaptop) {

    const laptop = await prisma.products.create({
      data: {
        name: "Laptop Pro",
        price: 420000,
        description: "Тестовый ноутбук",
        category_id: laptops.id,
        in_stock: true
      }
    });

    console.log("Создан товар:", laptop);

  } else {

    console.log("Laptop Pro уже существует");

  }


  // ==========================
  // Wireless Mouse
  // ==========================

  const existingMouse = await prisma.products.findFirst({
    where: {
      name: "Wireless Mouse"
    }
  });

  if (!existingMouse) {

    const mouse = await prisma.products.create({
      data: {
        name: "Wireless Mouse",
        price: 12000,
        description: "Тестовая беспроводная мышь",
        category_id: accessories.id,
        in_stock: true
      }
    });

    console.log("Создан товар:", mouse);

  } else {

    console.log("Wireless Mouse уже существует");

  }
}


main()
  .then(async () => {

    await prisma.$disconnect();

  })
  .catch(async (error) => {

    console.error(error);

    await prisma.$disconnect();

    process.exit(1);

  });

3. Запустите seed
npx prisma@7 generate
npx prisma@7 db seed

