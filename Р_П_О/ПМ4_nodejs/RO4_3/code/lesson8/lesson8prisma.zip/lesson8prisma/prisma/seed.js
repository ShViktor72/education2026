import { prisma } from "../config/prisma.js";

async function getOrCreateCategory(name) {
  // Сначала ищем категорию по имени
  const existingCategory = await prisma.categories.findFirst({
    where: {
      name: name
    }
  });

  if (existingCategory) {
    return existingCategory;
  }

  // Так как id не autoincrement,
  // определяем следующий свободный id
  const result = await prisma.categories.aggregate({
    _max: {
      id: true
    }
  });

  const nextId = (result._max.id ?? 0) + 1;

  return prisma.categories.create({
    data: {
      id: nextId,
      name: name
    }
  });
}


async function main() {

  // ==========================
  // Категории
  // ==========================

  const laptops = await getOrCreateCategory("Ноутбуки");

  const accessories = await getOrCreateCategory("Аксессуары");

  console.log("Категории:");
  console.log({ laptops, accessories });


  // ==========================
  // Laptop Pro
  // ==========================

  const existingLaptop = await prisma.products.findFirst({
    where: {
      name: "Laptop Pro"
    }
  });

  if (!existingLaptop) {

    const laptop = await prisma.products.create({
      data: {
        name: "Laptop Pro",
        price: 420000,
        description: "Тестовый ноутбук",
        category_id: laptops.id,
        in_stock: true
      }
    });

    console.log("Создан товар:", laptop);

  } else {

    console.log("Laptop Pro уже существует");

  }


  // ==========================
  // Wireless Mouse
  // ==========================

  const existingMouse = await prisma.products.findFirst({
    where: {
      name: "Wireless Mouse"
    }
  });

  if (!existingMouse) {

    const mouse = await prisma.products.create({
      data: {
        name: "Wireless Mouse",
        price: 12000,
        description: "Тестовая беспроводная мышь",
        category_id: accessories.id,
        in_stock: true
      }
    });

    console.log("Создан товар:", mouse);

  } else {

    console.log("Wireless Mouse уже существует");

  }
}


main()
  .then(async () => {

    await prisma.$disconnect();

  })
  .catch(async (error) => {

    console.error(error);

    await prisma.$disconnect();

    process.exit(1);

  });