import { pool } from "../config/db.js";

// READ — получить все товары
export async function getAllProducts() {
    const result = await pool.query(
        "SELECT * FROM products ORDER BY id"
    );
    return result.rows;
}

// READ — получить товар по ID
export async function findProductById(id) {
    const result = await pool.query(
        "SELECT * FROM products WHERE id = $1",
        [id]
    );
    return result.rows[0];
}

// CREATE — создать товар
export async function addProduct(data) {
    const result = await pool.query(
        `INSERT INTO products (name, price, category, in_stock)
         VALUES ($1, $2, $3, $4)
         RETURNING *`,
        [data.name, data.price, data.category, data.inStock]
    );
    return result.rows[0];
}

// UPDATE — изменить цену
export async function updateProductById(id, price) {
    const result = await pool.query(
        `UPDATE products SET price = $1
         WHERE id = $2 RETURNING *`,
        [price, id]
    );
    return result.rows[0];
}

// DELETE — удалить товар
export async function deleteProductById(id) {
    const result = await pool.query(
        "DELETE FROM products WHERE id = $1 RETURNING *",
        [id]
    );
    return result.rows[0];
}