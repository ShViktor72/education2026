import * as service from "../services/productService.js";

// GET /api/products
export async function getProducts(req, res) {
    res.json(await service.getAllProducts());
}

// GET /api/products/:id
export async function getProductById(req, res) {
    const product = await service.findProductById(req.params.id);

    if (!product) return res.sendStatus(404);

    res.json(product);
}

// POST /api/products
export async function createProduct(req, res) {
    const product = await service.addProduct(req.body);
    res.status(201).json(product);
}

// PATCH /api/products/:id
export async function updateProduct(req, res) {
    const product = await service.updateProductById(
        req.params.id,
        req.body.price
    );

    if (!product) return res.sendStatus(404);

    res.json(product);
}

// DELETE /api/products/:id
export async function deleteProduct(req, res) {
    const product = await service.deleteProductById(req.params.id);

    if (!product) return res.sendStatus(404);

    res.json(product);
}