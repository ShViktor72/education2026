import { pool } from "./config/db.js";

try {
    // Самый простой запрос:
    // он не зависит от таблицы products.
    const result = await pool.query(
        "SELECT NOW() AS current_time"
    );

    console.log("PostgreSQL работает:");
    console.log(result.rows[0]);
} catch (error) {
    console.error("Ошибка подключения:");
    console.error(error.message);
} finally {
    // Завершаем Pool, потому что это тестовый скрипт.
    await pool.end();
}