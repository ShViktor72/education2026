// Устанавливаем Express и PostgreSQL-драйвер
// npm install express pg

import express from "express";
import productRoutes from "./routes/productRoutes.js";

const app = express();

app.use(express.json());

app.use("/api/products", productRoutes);

// Централизованная обработка ошибок
app.use((err, req, res, next) => {
    console.error(err);
    res.status(500).json({ message: "Server error" });
});

app.listen(3000, () => {
    console.log("Server started on port 3000");
});