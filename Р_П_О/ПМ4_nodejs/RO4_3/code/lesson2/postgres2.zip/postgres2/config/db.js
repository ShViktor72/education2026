// Загружаем переменные из файла .env.
import { loadEnvFile } from "node:process";

// PostgreSQL-драйвер.
import { Pool } from "pg";

loadEnvFile();

// Создаём один общий Pool соединений.
// Он будет использоваться всеми Service.
export const pool = new Pool({
    host: process.env.PGHOST,
    port: Number(process.env.PGPORT),
    database: process.env.PGDATABASE,
    user: process.env.PGUSER,
    password: process.env.PGPASSWORD
});