import {
    body,
    checkExact,
    param
} from "express-validator";

export const createProductValidation = [
    body("name")
        .isString()
        .withMessage("name must be a string")
        .bail()
        .trim()
        .isLength({ min: 2, max: 150 })
        .withMessage("name length must be 2..150"),

    body("price")
        .isInt({ min: 1, max: 100000000 })
        .withMessage("price must be a positive integer")
        .toInt(),

    body("categoryId")
        .isInt({ min: 1 })
        .withMessage("categoryId must be a positive integer")
        .toInt(),

    body("inStock")
        .optional()
        .isBoolean()
        .withMessage("inStock must be boolean")
        .toBoolean(),

    checkExact([], {
        locations: ["body"],
        message: "Unknown field"
    })
];

export const productIdValidation = [
    param("id")
        .isInt({ min: 1 })
        .withMessage("id must be a positive integer")
        .toInt()
];
