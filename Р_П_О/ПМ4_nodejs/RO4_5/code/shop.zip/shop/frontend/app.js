import { apiFetch, APIError } from "./api.js";
import {
    setAuth,
    clearAuth
} from "./authState.js";
import { getCurrentUser } from "./authState.js";

async function login(email, password) {
    const data = await apiFetch("/auth/login", {
        method: "POST",
        body: {
            email,
            password
        }
    });

    setAuth(data);
    return data.user;
}

const guestSection = document.querySelector("#guest-section");
const userSection = document.querySelector("#user-section");
const userName = document.querySelector("#user-name");

function showGuestUI() {
    guestSection.hidden = false;
    userSection.hidden = true;
    userName.textContent = "";
}

function showAuthenticatedUI(user) {
    guestSection.hidden = true;
    // userSection.hidden = false;
    userName.textContent = `Здравствуйте, ${user.name}`;
}

// renderNavigation();
// location.hash = "#/profile";




const form = document.querySelector("#login-form");
const emailInput = document.querySelector("#email");
const passwordInput = document.querySelector("#password");
const loginButton = document.querySelector("#login-button");
const loginError = document.querySelector("#login-error");

form.addEventListener("submit", async (event) => {
    event.preventDefault();

    loginError.textContent = "";
    loginButton.disabled = true;

    try {
        const user = await login(
            emailInput.value,
            passwordInput.value
        );

        showAuthenticatedUI(user);
        form.reset();
    } catch (error) {
        loginError.textContent = error.message;
    } finally {
        loginButton.disabled = false;
    }
});


//
async function loadMyOrders() {
    return apiFetch("/orders/my");
}

const ordersButton = document.querySelector("#orders-button");
const ordersStatus = document.querySelector("#orders-status");
const ordersList = document.querySelector("#orders-list");

ordersButton.addEventListener("click", async () => {
    ordersStatus.textContent = "Загрузка...";
    ordersList.innerHTML = "";

    try {
        const orders = await loadMyOrders();

        ordersStatus.textContent = `Заказов: ${orders.length}`;

        for (const order of orders) {
            const element = document.createElement("div");
            element.textContent = `Заказ #${order.id}: ${order.status}`;
            ordersList.append(element);
        }
    } catch (error) {
        ordersStatus.textContent = error.message;

        if (error instanceof APIError && error.status === 401) {
            showGuestUI();
        }
    }
});

const logoutButton = document.querySelector("#logout-button");

logoutButton.addEventListener("click", () => {
    clearAuth();
    renderNavigation();
    location.hash = "#/login";

    ordersList.innerHTML = "";
    ordersStatus.textContent = "";
    showGuestUI();
});

const catalogSection = document.querySelector("#catalog-section");
const profileSection = document.querySelector("#profile-section");
const adminSection = document.querySelector("#admin-section");
const loginLink = document.querySelector("#login-link");
const profileLink = document.querySelector("#profile-link");
const adminLink = document.querySelector("#admin-link");
const profileName = document.querySelector("#profile-name");

function requireUser() {
    if (!getCurrentUser()) {
        location.hash = "#/login";
        return false;
    }
    return true;
}

function requireAdmin() {
    const user = getCurrentUser();
    if (!user) {
        location.hash = "#/login";
        return false;
    }
    if (user.role !== "admin") {
        alert("Недостаточно прав");
        location.hash = "#/catalog";
        return false;
    }
    return true;
}

function showOnly(section) {
    for (const item of [guestSection, userSection, catalogSection, profileSection, adminSection]) {
        item.hidden = item !== section;
    }
}

function renderPage() {
    const page = location.hash || "#/catalog";

    if (page === "#/profile") {
        if (!requireUser()) return;
        profileName.textContent = getCurrentUser().name;
        showOnly(profileSection);
    } else if (page === "#/admin") {
        if (!requireAdmin()) return;
        showOnly(adminSection);
    } else if (page === "#/login") {
        if (getCurrentUser()) {
            location.hash = "#/profile";
            return;
        }
        showOnly(guestSection);
    } else {
        showOnly(catalogSection);
    }
}

function renderNavigation() {
    const user = getCurrentUser();
    loginLink.hidden = Boolean(user);
    profileLink.hidden = !user;
    adminLink.hidden = user?.role !== "admin";
}

window.addEventListener("hashchange", renderPage);
renderNavigation();
renderPage();

