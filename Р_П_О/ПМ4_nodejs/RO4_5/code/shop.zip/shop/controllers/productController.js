import * as service from "../services/productService.js";

// GET /api/products
export async function getProducts(req, res) {
    const products = await service.getAllProducts();

    res.json(products);
}

// GET /api/products/:id
export async function getProductById(req, res) {
    try {
        const product = await service.findProductById(
            // Number(req.params.id)
            req.validated.id
        );

        if (!product) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        res.json(product);
    } catch (error) {
        next(error);
    }
}

// POST /api/products
// export async function createProduct(req, res) {
//     const product = await service.addProduct(req.body);

//     res.status(201).json(product);
// }
export async function createProduct(req, res, next) {
    try {
        const product = await service.addProduct(req.validated);

        res.status(201).json(product);
    } catch (error) {
        next(error);
    }
}


// PATCH /api/products/:id
export async function updateProduct(req, res) {
    const product = await service.updateProductById(
        Number(req.params.id),
        req.body
    );

    res.json(product);
}

// DELETE /api/products/:id
export async function deleteProduct(req, res) {
    const product = await service.deleteProductById(
        Number(req.params.id)
    );

    res.json(product);
}


// обработчики новых запросов
// GET /api/products/with-categories
export async function getWithCategories(req, res) {
    const products =
        await service.getProductsWithCategories();

    res.json(products);
}

// GET /api/products/selected
export async function getSelectedProducts(req, res) {
    const products =
        await service.getProductsSelected();

    res.json(products);
}

// GET /api/products/by-category?name=Electronics
export async function getByCategory(req, res) {
    const name = req.query.name;

    if (typeof name !== "string" || !name.trim()) {
        return res.status(400).json({
            message: "Category name is required"
        });
    }

    const products =
        await service.getProductsByCategory(name.trim());

    res.json(products);
}

// GET /api/products/by-category-id/1
export async function getByCategoryId(req, res) {
    const products =
        await service.getProductsByCategoryId(
            Number(req.params.id)
        );

    res.json(products);
}