import test from "node:test";
import assert from "node:assert/strict";
import { calculateOrderTotal } from "../services/orderMath.js";

test("calculates total for several items", () => {
    // Arrange
    const items = [
        { price: 10000, quantity: 2 },
        { price: 5000, quantity: 1 }
    ];

    // Act
    const total = calculateOrderTotal(items);

    // Assert
    assert.strictEqual(total, 25000);
});

test("calculates total for one item", () => {
  const items = [
    { price: 42000, quantity: 3 }
  ];

  const total = calculateOrderTotal(items);

  assert.strictEqual(total, 126000);
});

test("returns zero for empty items array", () => {
  const total = calculateOrderTotal([]);

  assert.strictEqual(total, 0);
});

test("accepts quantity equal to one", () => {
  const total = calculateOrderTotal([
    { price: 15000, quantity: 1 }
  ]);

  assert.strictEqual(total, 15000);
});

test("accepts quantity equal to one hundred", () => {
  const total = calculateOrderTotal([
    { price: 1000, quantity: 100 }
  ]);

  assert.strictEqual(total, 100000);
});

test("rejects quantity equal to zero", () => {
  assert.throws(
    () => calculateOrderTotal([
      { price: 10000, quantity: 0 }
    ]),
    /quantity/
  );
});

test("rejects quantity greater than one hundred", () => {
  assert.throws(
    () => calculateOrderTotal([
      { price: 10000, quantity: 101 }
    ]),
    /quantity/
  );
});

test("rejects non-positive price", () => {
  assert.throws(
    () => calculateOrderTotal([
      { price: 0, quantity: 1 }
    ]),
    /price/
  );
});

test("rejects non-array input", () => {
  assert.throws(
    () => calculateOrderTotal(null),
    /items/
  );
});

export function canCancelOrder(status) {
  return status === "new";
}

test("allows cancellation for new order", () => {
  assert.strictEqual(canCancelOrder("new"), true);
});

test("does not allow cancellation for paid order", () => {
  assert.strictEqual(canCancelOrder("paid"), false);
});

test("does not allow cancellation for shipped order", () => {
  assert.strictEqual(canCancelOrder("shipped"), false);
});
