import { prisma } from "../config/prisma.js";

// READ — список товаров
export async function getAllProducts() {
    return prisma.products.findMany({
        orderBy: { id: "asc" },
        include: { categories: true }
    });
}


// READ — товар по ID
export async function findProductById(id) {
    return prisma.products.findUnique({
        where: { id },
        include: { categories: true }
    });
}

// CREATE — добавить товар
export async function addProduct(data) {
    // console.log(data)
    return prisma.products.create({        
        data: {
            name: data.name,
            price: data.price,
            category_id: data.categoryId,
            in_stock: data.inStock ?? true,
            description: data.description
        },
        include: { categories: true }
    });
}

// UPDATE — частичное изменение
export async function updateProductById(id, changes) {
    return prisma.products.update({
        where: { id },
        data: changes,
        include: { categories: true }
    });
}

// DELETE — удалить товар
export async function deleteProductById(id) {
    return prisma.products.delete({
        where: { id },
        include: { categories: true }
    });
}


// новые функции , не удаляя методы CRUD.
// include загружает связанную модель
// вложенный select выбирает конкретные поля
// where фильтрetn записи по данным связанной категории.
// 1. Товары вместе с категориями — include
function formatProduct(product) {
    if (!product) return null;
    const { categories, ...fields } = product;
    return {
        ...fields,
        category: categories.name
    };
}

export async function getProductsWithCategories() {
    const products = await prisma.products.findMany({
        include: {
            categories: true
        },
        orderBy: { id: "asc" }
    });
    return products.map(formatProduct);
}

// 2. Только необходимые поля — вложенный select
export async function getProductsSelected() {
    const products = await prisma.products.findMany({
        select: {
            id: true,
            name: true,
            price: true,
            in_stock: true,
            categories: {
                select: {
                    id: true,
                    name: true
                }
            }
        },
        orderBy: { id: "asc" }
    });
    return products.map(formatProduct);
}

// 3. Поиск товаров по названию категории
export async function getProductsByCategory(categoryName) {
    return prisma.products.findMany({
        where: {
            categories: {
                is: {
                    name: categoryName
                }
            }
        },
        include: { categories: true }
    });
}

// 4. Поиск товаров по ID категории
export async function getProductsByCategoryId(categoryId) {
    return prisma.products.findMany({
        where: {
            category_id: Number(categoryId)
        },
        include: { categories: true }
    });
}