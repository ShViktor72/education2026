import { Router } from "express";
import * as controller from "../controllers/productController.js";
import { validateId, validateProduct } from "../middleware/validateProduct.js";
import { requireAuth, requireRole } from "../middleware/authMiddleware.js"
import { createProductValidation } from "../validators/productValidators.js"
import { validateRequest } from "../middleware/validationMiddleware.js"
import { productIdValidation } from "../validators/productValidators.js"

const router = Router();

router.get("/", controller.getProducts);

// новые маршруты
router.get(
    "/with-categories",
    controller.getWithCategories
);

router.get(
    "/selected",
    controller.getSelectedProducts
);

router.get(
    "/by-category",
    controller.getByCategory
);

router.get(
    "/by-category-id/:id",
    validateId,
    controller.getByCategoryId
);


// старые маршруты
router.get(
    "/:id",
    productIdValidation,
    validateRequest,
    controller.getProductById
);

router.post(
    "/",
    requireAuth,
    requireRole("admin"),
    createProductValidation,
    validateRequest,
    controller.createProduct
);

router.patch(
    "/:id",
    requireAuth,
    requireRole("admin"),
    validateId,
    validateProduct,
    controller.updateProduct
);

router.delete(
    "/:id",
    requireAuth,
    requireRole("admin"),
    validateId,
    controller.deleteProduct
);

export default router;