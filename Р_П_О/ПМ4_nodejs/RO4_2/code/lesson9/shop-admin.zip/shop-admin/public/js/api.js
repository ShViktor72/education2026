// Здесь все HTTP-запросы к серверу

// Функция request() проверяет response.ok и преобразует ответ сервера в JavaScript-данные.
async function request(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Ошибка запроса");
  return data;
}

export function getProducts() {
  return request("/api/products");
}

export function createProduct(product) {
  return request("/api/products", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(product),
  });
}
// Лабораторная: добавьте getCategories() и createCategory().
