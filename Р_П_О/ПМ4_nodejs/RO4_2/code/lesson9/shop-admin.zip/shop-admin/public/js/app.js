// Главный клиентский файл: связывает события браузера, HTTP-запросы и изменение DOM.

import { getProducts, createProduct } from './api.js';
import { renderProducts, showProductMessage } from './ui.js';

// Переключение вкладок без перезагрузки страницы.
for (const button of document.querySelectorAll('[data-tab]')) {
  button.addEventListener('click', () => {
    const selected = button.dataset.tab;
    document.querySelector('#products-panel').hidden = selected !== 'products';
    document.querySelector('#categories-panel').hidden = selected !== 'categories';
    for (const tab of document.querySelectorAll('[data-tab]')) {
      tab.classList.toggle('active', tab === button);
    }
  });
}

async function loadProducts() {
  const products = await getProducts();
  renderProducts(products);
}

const form = document.querySelector('#product-form');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const product = {
    name: document.querySelector('#name').value.trim(),
    price: Number(document.querySelector('#price').value)
  };
  try {
    await createProduct(product);
    form.reset();
    await loadProducts();
    showProductMessage('Товар добавлен');
  } catch (error) {
    showProductMessage(error.message, true);
  }
});

loadProducts().catch(error => showProductMessage(error.message, true));
// подключите загрузку и отправку категорий.

