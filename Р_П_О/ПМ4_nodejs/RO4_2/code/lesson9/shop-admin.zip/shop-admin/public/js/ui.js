// модуль отвечает за отображение данных и сообщений в интерфейсе.

export function renderProducts(products) {
  const list = document.querySelector('#products');
  list.replaceChildren();
  for (const product of products) {
    const item = document.createElement('li');
    item.textContent = `${product.name} — ${product.price} ₸`;
    list.append(item);
  }
}
export function showProductMessage(text, error = false) {
  const message = document.querySelector('#product-message');
  message.textContent = text;
  message.style.color = error ? '#a32121' : '#146c43';
}
// Лабораторная: добавьте renderCategories(categories).
