// Controller получает HTTP-запросы, вызывает функции Service и формирует ответы

import * as service from "../services/productService.js";

export function getAll(req, res) {
  res.json(service.getAllProducts());
}
export function create(req, res) {
  const { name, price } = req.body ?? {};
  if (
    typeof name !== "string" ||
    !name.trim() ||
    typeof price !== "number" ||
    !Number.isFinite(price) ||
    price < 0
  ) {
    return res
      .status(400)
      .json({ message: "Введите название и корректную цену" });
  }
  const product = service.createProduct({ name: name.trim(), price });
  res.status(201).json(product);
}
