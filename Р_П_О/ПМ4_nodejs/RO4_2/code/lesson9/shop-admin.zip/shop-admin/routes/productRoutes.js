// Router связывает HTTP-методы с контроллерами.

import { Router } from "express";
import * as controller from "../controllers/productController.js";
const router = Router();
router.get("/", controller.getAll);
router.post("/", controller.create);
export default router;
