// Главный файл Express-приложения.

import express from "express";
import productRoutes from "./routes/productRoutes.js";

const app = express();
app.use(express.json());
app.use(express.static("public"));
app.use("/api/products", productRoutes);
// Лабораторная: подключите categoryRoutes по пути /api/categories.

app.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ message: "Некорректный JSON" });
  }
  console.error(err);
  res.status(500).json({ message: "Ошибка сервера" });
});

app.listen(3000, () => console.log("http://localhost:3000"));
