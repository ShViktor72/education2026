// хранение данных и CRUD-операции

let products = [
  { id: 1, name: "Keyboard", price: 15000 },
  { id: 2, name: "Mouse", price: 8000 },
];
let nextId = 3;

export function getAllProducts() {
  return products;
}
export function createProduct(data) {
  const product = { id: nextId++, name: data.name, price: data.price };
  products.push(product);
  return product;
}
